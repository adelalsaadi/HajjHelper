import { Component } from '@angular/core';
import { ApiService} from "./shared/api.service"
declare var cordova;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [
  ]
})
export class AppComponent {
  loading = false;
  constructor(private api: ApiService) { 
    
    // console.log(cordova);
    document.addEventListener('deviceready', function() { 
      console.log(cordova);
      alert(cordova.platform); 
      }, false); 
       
      api.loading.subscribe(loading => this.loading = loading);
   
  }
}
