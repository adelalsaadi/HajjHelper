import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../service/patient.service'
import { DataService } from '../../shared/data.service';

enum Zone {
    all,
    private,
    public,
    hidden
}

declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    zone: Zone;
}
export const ROUTES: RouteInfo[] = [
    { path: '/dashboard', title: 'Home', icon: 'design_app', zone: Zone.all },
    { path: '/provider', title: 'Provider', icon: 'business_badge', zone: Zone.all },

    { path: '/apptlist', title: 'Appoitments', icon: 'ui-1_calendar-60', zone: Zone.private },
    { path: '/apptnew', title: 'Book new appoitment', icon: 'ui-1_bell-53', zone: Zone.private },
    { path: '/user-profile', title: 'My Profile', icon: 'users_circle-08', zone: Zone.private },
    { path: '/family', title: 'Family',  icon:'design_bullet-list-67', zone:  Zone.private  },
    { path: '/newfamily', title: 'New Member',  icon:'design_bullet-list-67', zone:  Zone.hidden  },

    { path: '/contactdetail', title: 'Contact US', icon: 'ui-1_email-85', zone: Zone.all },
    { path: '/contactus', title: 'Contact US', icon: 'ui-1_email-85', zone: Zone.hidden },

    { path: '/register', title: 'Register', icon: 'users_circle-08', zone: Zone.public },
    { path: '/login', title: 'login', icon: 'users_circle-08', zone: Zone.public },
];

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
    constructor(private patService: PatientService, private data: DataService) {
        
    }

    ngOnInit() {
    }
    isMobileMenu() {
        if (window.innerWidth > 991) {
            return false;
        }
        return true;
    };


    logOut() {
        this.patService.logout();
    };
}
