import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service'
import { ApiService } from '../shared/api.service'

declare const google: any;

@Component({
  selector: 'app-contact-detail',
  templateUrl: './contact.detail.component.html',
  styleUrls: ['./contact.detail.component.css']
})
export class ContactDetailComponent implements OnInit {


  constructor(private data: DataService, private api: ApiService) {
  }
  ngOnInit() {

  }

  goToContactUS(){
    this.api.gotoPage("/contactus");
  }
}
