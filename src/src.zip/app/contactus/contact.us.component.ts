import { Component, OnInit } from '@angular/core';
import { DataService } from '../shared/data.service'
import { ApiService } from '../shared/api.service'
import { Contact } from '../model/contact.model'

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact.us.component.html',
  styleUrls: ['./contact.us.component.css']
})
export class ContactUsComponent implements OnInit {
  practice;
  patient;
  appointments;
  reasons: string[];
  apptReason = false;
  contact = new Contact();
  apptDetail = "Select Appointment";
  constructor(private service: ApiService, private data: DataService) {
  }

  ngOnInit() {
    
  }

  

  SendMessage() {
    //this.api.sendContactUsMessage(this.contact)
  }

}
