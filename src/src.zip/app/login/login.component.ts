import { Component, OnInit } from '@angular/core';
import { PatientService } from '../service/patient.service'
import { Login } from '../model/patient.model'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[PatientService]
})
export class LoginComponent implements OnInit {

  login = new Login();
  
  constructor(private service: PatientService) { 

  }

  ngOnInit() {
  }

  Logme(){
    this.service.login(this.login);
    
  }
}
