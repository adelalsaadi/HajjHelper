export class Contact {
    name: string;
    email: string;
    mobile: string;
    reason: string;
    message: string;
}