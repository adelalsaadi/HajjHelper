export class Patient{
    patNum:number;
    name:string;
    number:number;
    age:number;
    gender:number;
    nationalty:string;
    body:string;
    eye:number;
    verbal:number;
    motor:number;
    gcs:number;
}

export class Login{
    Email:string;
    Password:string;
    PasswordRecovery: boolean;
}





