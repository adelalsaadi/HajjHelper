import { Component, OnInit } from '@angular/core';
import { PatientService } from '../service/patient.service'
import { Patient } from '../model/patient.model'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [PatientService]
})
export class RegisterComponent implements OnInit {

  constructor(private service: PatientService) {
  }
  patient = new Patient();
  passwordConfirm: string;
  passwordMismatch = false;
  ngOnInit() {
  }

  register() {
    //this.patient.country = "Saudi Arabia";
    //this.service.register(this.patient);
  }
  gotoLogin() {
    this.service.gotoPage("/login");
  }

  matchPassword() {
    console.log(this.passwordMismatch)
    // if (this.passwordConfirm != this.patient.password)
    //   this.passwordMismatch = true;
    // else
    //   this.passwordMismatch = false;
  }
}
