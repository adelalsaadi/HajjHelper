import { Injectable } from '@angular/core';
import { ApiService } from '../shared/api.service';
import { DataService } from '../shared/data.service';
import { Patient, Login } from '../model/patient.model';
import { NgxAlertsService } from '@ngx-plus/ngx-alerts';

@Injectable()
export class PatientService {


  private action = {
    Login: "Token/Login",
    Register: "Token/Register",
    GetAppointments: "Patient/GetAppointments",
    AddMember: "Patient/AddMember",
    GetFamily: "Patient/GetFamily"
  }



  constructor(private api: ApiService, private alert: NgxAlertsService
    , private data: DataService) {
  }

  register(patient: Patient) {
    this.api.post<any>(this.action.Register, patient).subscribe(pat => {
      if (pat.patNum > 0)
        this.alert.alertSuccess({
          title: 'Register',
          text: 'Registeration success please login',
        })
        this.api.gotoPage("/login");
    });
  }

  login(login: Login) {
    this.api.login(login).subscribe(data => {
      if (data) {
        this.data.setAuthStatus(data.token)
        this.api.gotoPage();
      }
    })
  }

  logout() {
    this.api.logout();
  }

  gotoPage(route = "/") {
    this.api.gotoPage(route);
  }
}