import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { DataService } from './data.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class ApiService {
    baseUrl: string = environment.apiUrl;

    private _loading = new BehaviorSubject<boolean>(false);
    loading = this._loading.asObservable();

    private action = {
        Login: "Token/Login",
        Signin: "Token/Signin"
    }


    private headers;

    constructor(private httpClient: HttpClient, private router: Router, private data: DataService) {

    }

    

    post<T>(method, params = null): Observable<T> {
this._loading.next(true);
        this.headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        })

        return this.httpClient.post<T>(this.baseUrl + method, params, { headers: this.headers })
        .map(response =>{
            this._loading.next(false);
            return response;
        })
        .catch((e: any) => {            
            this._loading.next(false);
            return Observable.throw(this.errorHandler(e));
        });
    }
  
    errorHandler(error: any): void {
      console.log(error)
      return error;
    }

    login(login) {
        return this.post<any>(this.action.Login, login);
    }

    signin(login) {
        return this.post<any>(this.action.Signin, login);
    }

    logout() {
        localStorage.clear();
        sessionStorage.clear();
        this.data.setAuthStatus(null);
        this.router.navigateByUrl("/");
    }
    gotoPage(route = "/") {
        this.router.navigate([route]);
    }

}