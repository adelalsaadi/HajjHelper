export const environment = {
    production: false,
    apiUrl: "http://192.168.1.7:45455/Api/"
  };
  