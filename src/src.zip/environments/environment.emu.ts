export const environment = {
  production: false,
  apiUrl: "http://10.0.2.2:45455/Api/"
};
