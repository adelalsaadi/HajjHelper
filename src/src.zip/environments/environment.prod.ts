export const environment = {
    production: true,
    apiUrl: "http://10.0.2.2:45455/Api/"
  };
  